﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        decimal result = 0;
        private void InitField()
        {
            if (InputField.Text.IndexOf('=') != -1)
            {
                InputField.Text = result.ToString();
            }
        }
        private void OneButton_Click(object sender, EventArgs e)
        {
            InputField.Text+="1";

        }

        private void TwoButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "2";
        }

        private void ThreeButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "3";
        }

        private void FourButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "4";
        }

        private void FiveButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "5";
        }

        private void SixButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "6";
        }

        private void SevenButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "7";
        }

        private void EightButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "8";
        }

        private void NineButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "9";
        }

        private void ZeroButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "0";
        }

        private void DotButton_Click(object sender, EventArgs e)
        {
            InputField.Text += ".";
        }

        private void CButton_Click(object sender, EventArgs e)
        {
            InputField.Text = "";
        }

        private void DivButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "/";
        }

        private void MultButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "*";
        }

        private void MinusButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "-";
        }

        private void PlusButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "+";
        }

        private void OpenBracketButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "(";
        }

        private void CloseBracketButton_Click(object sender, EventArgs e)
        {
            InputField.Text += ")";
        }

        private void PowButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "^";
        }

        private void SinButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "sin";
        }

        private void CosButton_Click(object sender, EventArgs e)
        {
            InputField.Text += "cos";
        }

        private void tan_Click(object sender, EventArgs e)
        {
            InputField.Text += "tan";
        }

        private void ctan_Click(object sender, EventArgs e)
        {
            InputField.Text += "ctan";
        }

        private void log_Click(object sender, EventArgs e)
        {
            InputField.Text += "log";
        }

      
  
        private void sqrt_Click(object sender, EventArgs e)
        {
            InputField.Text += "sqrt";
        }
        decimal d;
        private void EqualsButton_Click(object sender, EventArgs e)
        {
            d = 0;
            calculation calculation = new calculation();
            try
            {
                d=calculation.result(InputField.Text);
                InputField.Text += "=" + d;
            }
            catch (Exception)
            {
                MessageBox.Show("Wrong input");
            }
        }

        private void BackspaceButton_Click(object sender, EventArgs e)
        {
            InputField.Text = InputField.Text.Remove(InputField.Text.Length - 1, 1);
        }

        private void ln_Click(object sender, EventArgs e)
        {
            InputField.Text += "ln";

        }

 
    }
}
