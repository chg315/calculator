﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ln = new System.Windows.Forms.Button();
            this.log = new System.Windows.Forms.Button();
            this.sqrt = new System.Windows.Forms.Button();
            this.ctan = new System.Windows.Forms.Button();
            this.tan = new System.Windows.Forms.Button();
            this.CosButton = new System.Windows.Forms.Button();
            this.SinButton = new System.Windows.Forms.Button();
            this.CButton = new System.Windows.Forms.Button();
            this.BackspaceButton = new System.Windows.Forms.Button();
            this.InputField = new System.Windows.Forms.TextBox();
            this.OpenBracketButton = new System.Windows.Forms.Button();
            this.PowButton = new System.Windows.Forms.Button();
            this.DotButton = new System.Windows.Forms.Button();
            this.DivButton = new System.Windows.Forms.Button();
            this.CloseBracketButton = new System.Windows.Forms.Button();
            this.EqualsButton = new System.Windows.Forms.Button();
            this.MultButton = new System.Windows.Forms.Button();
            this.MinusButton = new System.Windows.Forms.Button();
            this.PlusButton = new System.Windows.Forms.Button();
            this.NineButton = new System.Windows.Forms.Button();
            this.EightButton = new System.Windows.Forms.Button();
            this.SevenButton = new System.Windows.Forms.Button();
            this.SixButton = new System.Windows.Forms.Button();
            this.FiveButton = new System.Windows.Forms.Button();
            this.FourButton = new System.Windows.Forms.Button();
            this.ThreeButton = new System.Windows.Forms.Button();
            this.TwoButton = new System.Windows.Forms.Button();
            this.OneButton = new System.Windows.Forms.Button();
            this.ZeroButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ln
            // 
            this.ln.Location = new System.Drawing.Point(624, 238);
            this.ln.Margin = new System.Windows.Forms.Padding(4);
            this.ln.Name = "ln";
            this.ln.Size = new System.Drawing.Size(101, 42);
            this.ln.TabIndex = 59;
            this.ln.Text = "ln";
            this.ln.UseVisualStyleBackColor = true;
            this.ln.Click += new System.EventHandler(this.ln_Click);
            // 
            // log
            // 
            this.log.Location = new System.Drawing.Point(624, 189);
            this.log.Margin = new System.Windows.Forms.Padding(4);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(101, 42);
            this.log.TabIndex = 58;
            this.log.Text = "log";
            this.log.UseVisualStyleBackColor = true;
            this.log.Click += new System.EventHandler(this.log_Click);
            // 
            // sqrt
            // 
            this.sqrt.Location = new System.Drawing.Point(624, 295);
            this.sqrt.Margin = new System.Windows.Forms.Padding(4);
            this.sqrt.Name = "sqrt";
            this.sqrt.Size = new System.Drawing.Size(101, 46);
            this.sqrt.TabIndex = 57;
            this.sqrt.Text = "sqrt";
            this.sqrt.UseVisualStyleBackColor = true;
            this.sqrt.Click += new System.EventHandler(this.sqrt_Click);
            // 
            // ctan
            // 
            this.ctan.Location = new System.Drawing.Point(515, 344);
            this.ctan.Margin = new System.Windows.Forms.Padding(4);
            this.ctan.Name = "ctan";
            this.ctan.Size = new System.Drawing.Size(101, 46);
            this.ctan.TabIndex = 56;
            this.ctan.Text = "ctan";
            this.ctan.UseVisualStyleBackColor = true;
            this.ctan.Click += new System.EventHandler(this.ctan_Click);
            // 
            // tan
            // 
            this.tan.Location = new System.Drawing.Point(515, 295);
            this.tan.Margin = new System.Windows.Forms.Padding(4);
            this.tan.Name = "tan";
            this.tan.Size = new System.Drawing.Size(101, 42);
            this.tan.TabIndex = 55;
            this.tan.Text = "tan";
            this.tan.UseVisualStyleBackColor = true;
            this.tan.Click += new System.EventHandler(this.tan_Click);
            // 
            // CosButton
            // 
            this.CosButton.Location = new System.Drawing.Point(515, 238);
            this.CosButton.Margin = new System.Windows.Forms.Padding(4);
            this.CosButton.Name = "CosButton";
            this.CosButton.Size = new System.Drawing.Size(101, 42);
            this.CosButton.TabIndex = 54;
            this.CosButton.Text = "cos";
            this.CosButton.UseVisualStyleBackColor = true;
            this.CosButton.Click += new System.EventHandler(this.CosButton_Click);
            // 
            // SinButton
            // 
            this.SinButton.Location = new System.Drawing.Point(515, 189);
            this.SinButton.Margin = new System.Windows.Forms.Padding(4);
            this.SinButton.Name = "SinButton";
            this.SinButton.Size = new System.Drawing.Size(101, 42);
            this.SinButton.TabIndex = 53;
            this.SinButton.Text = "sin";
            this.SinButton.UseVisualStyleBackColor = true;
            this.SinButton.Click += new System.EventHandler(this.SinButton_Click);
            // 
            // CButton
            // 
            this.CButton.Location = new System.Drawing.Point(76, 140);
            this.CButton.Margin = new System.Windows.Forms.Padding(4);
            this.CButton.Name = "CButton";
            this.CButton.Size = new System.Drawing.Size(139, 42);
            this.CButton.TabIndex = 52;
            this.CButton.Text = "C";
            this.CButton.UseVisualStyleBackColor = true;
            this.CButton.Click += new System.EventHandler(this.CButton_Click);
            // 
            // BackspaceButton
            // 
            this.BackspaceButton.Location = new System.Drawing.Point(223, 140);
            this.BackspaceButton.Margin = new System.Windows.Forms.Padding(4);
            this.BackspaceButton.Name = "BackspaceButton";
            this.BackspaceButton.Size = new System.Drawing.Size(175, 42);
            this.BackspaceButton.TabIndex = 51;
            this.BackspaceButton.Text = "Backspace";
            this.BackspaceButton.UseVisualStyleBackColor = true;
            this.BackspaceButton.Click += new System.EventHandler(this.BackspaceButton_Click);
            // 
            // InputField
            // 
            this.InputField.Location = new System.Drawing.Point(76, 61);
            this.InputField.Margin = new System.Windows.Forms.Padding(4);
            this.InputField.Name = "InputField";
            this.InputField.Size = new System.Drawing.Size(628, 22);
            this.InputField.TabIndex = 50;
            // 
            // OpenBracketButton
            // 
            this.OpenBracketButton.Location = new System.Drawing.Point(405, 140);
            this.OpenBracketButton.Margin = new System.Windows.Forms.Padding(4);
            this.OpenBracketButton.Name = "OpenBracketButton";
            this.OpenBracketButton.Size = new System.Drawing.Size(101, 42);
            this.OpenBracketButton.TabIndex = 49;
            this.OpenBracketButton.Text = "(";
            this.OpenBracketButton.UseVisualStyleBackColor = true;
            this.OpenBracketButton.Click += new System.EventHandler(this.OpenBracketButton_Click);
            // 
            // PowButton
            // 
            this.PowButton.Location = new System.Drawing.Point(405, 238);
            this.PowButton.Margin = new System.Windows.Forms.Padding(4);
            this.PowButton.Name = "PowButton";
            this.PowButton.Size = new System.Drawing.Size(101, 46);
            this.PowButton.TabIndex = 48;
            this.PowButton.Text = "^";
            this.PowButton.UseVisualStyleBackColor = true;
            this.PowButton.Click += new System.EventHandler(this.PowButton_Click);
            // 
            // DotButton
            // 
            this.DotButton.Location = new System.Drawing.Point(223, 348);
            this.DotButton.Margin = new System.Windows.Forms.Padding(4);
            this.DotButton.Name = "DotButton";
            this.DotButton.Size = new System.Drawing.Size(65, 42);
            this.DotButton.TabIndex = 47;
            this.DotButton.Text = ",";
            this.DotButton.UseVisualStyleBackColor = true;
            this.DotButton.Click += new System.EventHandler(this.DotButton_Click);
            // 
            // DivButton
            // 
            this.DivButton.Location = new System.Drawing.Point(296, 189);
            this.DivButton.Margin = new System.Windows.Forms.Padding(4);
            this.DivButton.Name = "DivButton";
            this.DivButton.Size = new System.Drawing.Size(101, 46);
            this.DivButton.TabIndex = 46;
            this.DivButton.Text = "/";
            this.DivButton.UseVisualStyleBackColor = true;
            this.DivButton.Click += new System.EventHandler(this.DivButton_Click);
            // 
            // CloseBracketButton
            // 
            this.CloseBracketButton.Location = new System.Drawing.Point(405, 189);
            this.CloseBracketButton.Margin = new System.Windows.Forms.Padding(4);
            this.CloseBracketButton.Name = "CloseBracketButton";
            this.CloseBracketButton.Size = new System.Drawing.Size(101, 42);
            this.CloseBracketButton.TabIndex = 45;
            this.CloseBracketButton.Text = ")";
            this.CloseBracketButton.UseVisualStyleBackColor = true;
            this.CloseBracketButton.Click += new System.EventHandler(this.CloseBracketButton_Click);
            // 
            // EqualsButton
            // 
            this.EqualsButton.Location = new System.Drawing.Point(405, 295);
            this.EqualsButton.Margin = new System.Windows.Forms.Padding(4);
            this.EqualsButton.Name = "EqualsButton";
            this.EqualsButton.Size = new System.Drawing.Size(101, 95);
            this.EqualsButton.TabIndex = 44;
            this.EqualsButton.Text = "=";
            this.EqualsButton.UseVisualStyleBackColor = true;
            this.EqualsButton.Click += new System.EventHandler(this.EqualsButton_Click);
            // 
            // MultButton
            // 
            this.MultButton.Location = new System.Drawing.Point(296, 242);
            this.MultButton.Margin = new System.Windows.Forms.Padding(4);
            this.MultButton.Name = "MultButton";
            this.MultButton.Size = new System.Drawing.Size(101, 46);
            this.MultButton.TabIndex = 43;
            this.MultButton.Text = "*";
            this.MultButton.UseVisualStyleBackColor = true;
            this.MultButton.Click += new System.EventHandler(this.MultButton_Click);
            // 
            // MinusButton
            // 
            this.MinusButton.Location = new System.Drawing.Point(296, 295);
            this.MinusButton.Margin = new System.Windows.Forms.Padding(4);
            this.MinusButton.Name = "MinusButton";
            this.MinusButton.Size = new System.Drawing.Size(101, 46);
            this.MinusButton.TabIndex = 42;
            this.MinusButton.Text = "-";
            this.MinusButton.UseVisualStyleBackColor = true;
            this.MinusButton.Click += new System.EventHandler(this.MinusButton_Click);
            // 
            // PlusButton
            // 
            this.PlusButton.Location = new System.Drawing.Point(296, 348);
            this.PlusButton.Margin = new System.Windows.Forms.Padding(4);
            this.PlusButton.Name = "PlusButton";
            this.PlusButton.Size = new System.Drawing.Size(101, 42);
            this.PlusButton.TabIndex = 41;
            this.PlusButton.Text = "+";
            this.PlusButton.UseVisualStyleBackColor = true;
            this.PlusButton.Click += new System.EventHandler(this.PlusButton_Click);
            // 
            // NineButton
            // 
            this.NineButton.Location = new System.Drawing.Point(223, 189);
            this.NineButton.Margin = new System.Windows.Forms.Padding(4);
            this.NineButton.Name = "NineButton";
            this.NineButton.Size = new System.Drawing.Size(65, 46);
            this.NineButton.TabIndex = 40;
            this.NineButton.Text = "9";
            this.NineButton.UseVisualStyleBackColor = true;
            this.NineButton.Click += new System.EventHandler(this.NineButton_Click);
            // 
            // EightButton
            // 
            this.EightButton.Location = new System.Drawing.Point(149, 189);
            this.EightButton.Margin = new System.Windows.Forms.Padding(4);
            this.EightButton.Name = "EightButton";
            this.EightButton.Size = new System.Drawing.Size(65, 46);
            this.EightButton.TabIndex = 39;
            this.EightButton.Text = "8";
            this.EightButton.UseVisualStyleBackColor = true;
            this.EightButton.Click += new System.EventHandler(this.EightButton_Click);
            // 
            // SevenButton
            // 
            this.SevenButton.Location = new System.Drawing.Point(76, 189);
            this.SevenButton.Margin = new System.Windows.Forms.Padding(4);
            this.SevenButton.Name = "SevenButton";
            this.SevenButton.Size = new System.Drawing.Size(65, 46);
            this.SevenButton.TabIndex = 38;
            this.SevenButton.Text = "7";
            this.SevenButton.UseVisualStyleBackColor = true;
            this.SevenButton.Click += new System.EventHandler(this.SevenButton_Click);
            // 
            // SixButton
            // 
            this.SixButton.Location = new System.Drawing.Point(223, 242);
            this.SixButton.Margin = new System.Windows.Forms.Padding(4);
            this.SixButton.Name = "SixButton";
            this.SixButton.Size = new System.Drawing.Size(65, 46);
            this.SixButton.TabIndex = 37;
            this.SixButton.Text = "6";
            this.SixButton.UseVisualStyleBackColor = true;
            this.SixButton.Click += new System.EventHandler(this.SixButton_Click);
            // 
            // FiveButton
            // 
            this.FiveButton.Location = new System.Drawing.Point(149, 242);
            this.FiveButton.Margin = new System.Windows.Forms.Padding(4);
            this.FiveButton.Name = "FiveButton";
            this.FiveButton.Size = new System.Drawing.Size(65, 46);
            this.FiveButton.TabIndex = 36;
            this.FiveButton.Text = "5";
            this.FiveButton.UseVisualStyleBackColor = true;
            this.FiveButton.Click += new System.EventHandler(this.FiveButton_Click);
            // 
            // FourButton
            // 
            this.FourButton.Location = new System.Drawing.Point(76, 242);
            this.FourButton.Margin = new System.Windows.Forms.Padding(4);
            this.FourButton.Name = "FourButton";
            this.FourButton.Size = new System.Drawing.Size(65, 46);
            this.FourButton.TabIndex = 35;
            this.FourButton.Text = "4";
            this.FourButton.UseVisualStyleBackColor = true;
            this.FourButton.Click += new System.EventHandler(this.FourButton_Click);
            // 
            // ThreeButton
            // 
            this.ThreeButton.Location = new System.Drawing.Point(223, 295);
            this.ThreeButton.Margin = new System.Windows.Forms.Padding(4);
            this.ThreeButton.Name = "ThreeButton";
            this.ThreeButton.Size = new System.Drawing.Size(65, 46);
            this.ThreeButton.TabIndex = 34;
            this.ThreeButton.Text = "3";
            this.ThreeButton.UseVisualStyleBackColor = true;
            this.ThreeButton.Click += new System.EventHandler(this.ThreeButton_Click);
            // 
            // TwoButton
            // 
            this.TwoButton.Location = new System.Drawing.Point(149, 295);
            this.TwoButton.Margin = new System.Windows.Forms.Padding(4);
            this.TwoButton.Name = "TwoButton";
            this.TwoButton.Size = new System.Drawing.Size(65, 46);
            this.TwoButton.TabIndex = 33;
            this.TwoButton.Text = "2";
            this.TwoButton.UseVisualStyleBackColor = true;
            this.TwoButton.Click += new System.EventHandler(this.TwoButton_Click);
            // 
            // OneButton
            // 
            this.OneButton.Location = new System.Drawing.Point(76, 295);
            this.OneButton.Margin = new System.Windows.Forms.Padding(4);
            this.OneButton.Name = "OneButton";
            this.OneButton.Size = new System.Drawing.Size(65, 46);
            this.OneButton.TabIndex = 32;
            this.OneButton.Text = "1";
            this.OneButton.UseVisualStyleBackColor = true;
            this.OneButton.Click += new System.EventHandler(this.OneButton_Click);
            // 
            // ZeroButton
            // 
            this.ZeroButton.Location = new System.Drawing.Point(76, 348);
            this.ZeroButton.Margin = new System.Windows.Forms.Padding(4);
            this.ZeroButton.Name = "ZeroButton";
            this.ZeroButton.Size = new System.Drawing.Size(139, 42);
            this.ZeroButton.TabIndex = 31;
            this.ZeroButton.Text = "0";
            this.ZeroButton.UseVisualStyleBackColor = true;
            this.ZeroButton.Click += new System.EventHandler(this.ZeroButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ln);
            this.Controls.Add(this.log);
            this.Controls.Add(this.sqrt);
            this.Controls.Add(this.ctan);
            this.Controls.Add(this.tan);
            this.Controls.Add(this.CosButton);
            this.Controls.Add(this.SinButton);
            this.Controls.Add(this.CButton);
            this.Controls.Add(this.BackspaceButton);
            this.Controls.Add(this.InputField);
            this.Controls.Add(this.OpenBracketButton);
            this.Controls.Add(this.PowButton);
            this.Controls.Add(this.DotButton);
            this.Controls.Add(this.DivButton);
            this.Controls.Add(this.CloseBracketButton);
            this.Controls.Add(this.EqualsButton);
            this.Controls.Add(this.MultButton);
            this.Controls.Add(this.MinusButton);
            this.Controls.Add(this.PlusButton);
            this.Controls.Add(this.NineButton);
            this.Controls.Add(this.EightButton);
            this.Controls.Add(this.SevenButton);
            this.Controls.Add(this.SixButton);
            this.Controls.Add(this.FiveButton);
            this.Controls.Add(this.FourButton);
            this.Controls.Add(this.ThreeButton);
            this.Controls.Add(this.TwoButton);
            this.Controls.Add(this.OneButton);
            this.Controls.Add(this.ZeroButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button ln;
        private System.Windows.Forms.Button log;
        private System.Windows.Forms.Button sqrt;
        private System.Windows.Forms.Button ctan;
        private System.Windows.Forms.Button tan;
        private System.Windows.Forms.Button CosButton;
        private System.Windows.Forms.Button SinButton;
        private System.Windows.Forms.Button CButton;
        private System.Windows.Forms.Button BackspaceButton;
        private System.Windows.Forms.TextBox InputField;
        private System.Windows.Forms.Button OpenBracketButton;
        private System.Windows.Forms.Button PowButton;
        private System.Windows.Forms.Button DotButton;
        private System.Windows.Forms.Button DivButton;
        private System.Windows.Forms.Button CloseBracketButton;
        private System.Windows.Forms.Button EqualsButton;
        private System.Windows.Forms.Button MultButton;
        private System.Windows.Forms.Button MinusButton;
        private System.Windows.Forms.Button PlusButton;
        private System.Windows.Forms.Button NineButton;
        private System.Windows.Forms.Button EightButton;
        private System.Windows.Forms.Button SevenButton;
        private System.Windows.Forms.Button SixButton;
        private System.Windows.Forms.Button FiveButton;
        private System.Windows.Forms.Button FourButton;
        private System.Windows.Forms.Button ThreeButton;
        private System.Windows.Forms.Button TwoButton;
        private System.Windows.Forms.Button OneButton;
        private System.Windows.Forms.Button ZeroButton;
    }
}

